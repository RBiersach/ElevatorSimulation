package com.example.elevatorsimulator;

public class AddPassenger {
    public String passengerType;
}
