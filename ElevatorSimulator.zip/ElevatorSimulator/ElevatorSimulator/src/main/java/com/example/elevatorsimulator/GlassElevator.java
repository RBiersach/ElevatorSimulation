package com.example.elevatorsimulator;

public class GlassElevator extends Elevator{
    public GlassElevator(int elevatorID) {
        super(elevatorID, "GlassElevator");
        // Additional initialization for GlassElevator
    }
    @Override
    public boolean move(direction _direction) {
        // Implement the movement logic for a glass elevator
        // Example: Move the elevator up or down based on _direction
        if (_direction == direction.UP) {
            // Implement the logic to move the elevator up
        }
        else if (_direction == direction.DOWN) {
            // Implement the logic to move the elevator down
        } else {
            System.out.println("Incorrect Input");
            return false;
        }
        return true;
    }
}