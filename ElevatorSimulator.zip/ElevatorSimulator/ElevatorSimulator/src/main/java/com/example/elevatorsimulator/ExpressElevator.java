package com.example.elevatorsimulator;

public class ExpressElevator extends Elevator{
    @Override
    public boolean move(direction _direction) {
        return false;
    }
}
