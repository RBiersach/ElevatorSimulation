package com.example.elevatorsimulator;

import java.util.ArrayList;

public class Floor {
    ArrayList<Passenger> waitQueue = new ArrayList<>();
    ArrayList<Passenger> completedQueue = new ArrayList<>();
    ArrayList<Elevator> currentElevators = new ArrayList<>();

    public Floor(int floorNumber) {
        // Initialize the floor and collections
    }

    public ArrayList<Passenger> getWaitQueue() {
        return waitQueue;
    }

    public ArrayList<Passenger> getCompletedQueue() {
        return completedQueue;
    }

    public ArrayList<Elevator> getCurrentElevators() {
        return currentElevators;
    }

}

