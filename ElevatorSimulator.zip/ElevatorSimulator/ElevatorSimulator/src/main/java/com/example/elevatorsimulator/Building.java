package com.example.elevatorsimulator;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Building {
    ArrayList<Floor> Floors = new ArrayList<>();

    public Building(int numFloors) {
        for (int i = 0; i < numFloors; i++) {
            Floors.add(new Floor(i));
        }
    }
}
