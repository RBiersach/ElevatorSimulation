package com.example.elevatorsimulator;

public class PassengerRequestPercentage {
    public String passengerType;
    public double percentage;
    public PassengerRequestPercentage(String passengerType, double percentage) {
        this.passengerType = passengerType;
        this.percentage = percentage;
    }

    // Getters and setters for passengerType and percentage
    public String getPassengerType() {
        return passengerType;
    }

    public void setPassengerType(String passengerType) {
        this.passengerType = passengerType;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    @Override
    public String toString() {
        return "PassengerRequestPercentage{" +
                "passengerType='" + passengerType + '\'' +
                ", percentage=" + percentage +
                '}';
    }
}

