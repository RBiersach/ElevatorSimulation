package com.example.elevatorsimulator;

public class StandardPassenger extends Passenger {
    public StandardPassenger(int passengerID, int startFloor, int endFloor) {
        this.passengerID = passengerID;
        this.startFloor = startFloor;
        this.endFloor = endFloor;
    }
    @Override
    public boolean requestElevator(direction _direction, SimulationSettings _settings) {
        return false;
    }
}
